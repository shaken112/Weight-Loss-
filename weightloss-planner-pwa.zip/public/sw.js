const CACHE = "wlp-cache-v1";
const ASSETS = ["/","/index.html","/manifest.webmanifest","/src/styles.css"];
self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c)=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener("activate", (e)=>{
  e.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>k===CACHE?null:caches.delete(k)))));
});
self.addEventListener("fetch", (e)=>{
  e.respondWith(
    caches.match(e.request).then((res)=> res || fetch(e.request).then((net)=>{
      const copy = net.clone();
      caches.open(CACHE).then((c)=> c.put(e.request, copy)).catch(()=>{});
      return net;
    }).catch(()=>res))
  );
});
