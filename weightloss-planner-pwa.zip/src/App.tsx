import React, { useEffect, useMemo, useState } from "react";
import { CheckCircle, Circle, RefreshCw, Settings, Calendar, Dumbbell, Salad, Flame, Download, Sun } from "lucide-react";
import { clamp, round, calcBMR, activityMultiplier, dailyDeficitFromGoal, macroSplit } from "./lib";

const LS_KEY = "dkrfc_weightloss_v1";
const dateKey = (d=new Date())=>{ const tz = new Date(d.getTime()-d.getTimezoneOffset()*60000); return tz.toISOString().slice(0,10); };
const loadState = ()=>{ try { return JSON.parse(localStorage.getItem(LS_KEY) || "{}"); } catch { return {}; } };
const saveState = (obj:any)=> localStorage.setItem(LS_KEY, JSON.stringify(obj));

const MEAL_LIBRARY:any = {
  breakfast: [
    { name: "Greek yogurt bowl", items: [
      { label: "Greek yogurt (2% fat)", qty: 300, unit: "g", kcal: 174, p: 30, c: 10, f: 4 },
      { label: "Rolled oats", qty: 40, unit: "g", kcal: 150, p: 5, c: 27, f: 3 },
      { label: "Mixed berries", qty: 100, unit: "g", kcal: 57, p: 1, c: 14, f: 0 },
      { label: "Honey", qty: 10, unit: "g", kcal: 30, p: 0, c: 8, f: 0 },
    ]},
    { name: "Eggs & toast", items: [
      { label: "Eggs", qty: 3, unit: "large", kcal: 210, p: 18, c: 2, f: 15 },
      { label: "Wholegrain toast", qty: 2, unit: "slices", kcal: 180, p: 8, c: 32, f: 3 },
      { label: "Avocado", qty: 60, unit: "g", kcal: 96, p: 1, c: 5, f: 9 },
    ]},
    { name: "Protein smoothie", items: [
      { label: "Whey protein", qty: 1, unit: "scoop", kcal: 120, p: 24, c: 3, f: 2 },
      { label: "Banana", qty: 1, unit: "medium", kcal: 105, p: 1, c: 27, f: 0 },
      { label: "Peanut butter", qty: 20, unit: "g", kcal: 118, p: 5, c: 4, f: 10 },
      { label: "Low-fat milk", qty: 300, unit: "ml", kcal: 138, p: 10, c: 15, f: 4 },
    ]},
  ],
  lunch: [
    { name: "Chicken rice bowl", items: [
      { label: "Chicken breast (cooked)", qty: 180, unit: "g", kcal: 297, p: 54, c: 0, f: 6 },
      { label: "Basmati rice (cooked)", qty: 250, unit: "g", kcal: 325, p: 6, c: 71, f: 1 },
      { label: "Mixed salad + olive oil", qty: 1, unit: "bowl", kcal: 120, p: 3, c: 10, f: 8 },
    ]},
    { name: "Beef quinoa", items: [
      { label: "Lean beef (cooked)", qty: 160, unit: "g", kcal: 304, p: 44, c: 0, f: 12 },
      { label: "Quinoa (cooked)", qty: 200, unit: "g", kcal: 240, p: 8, c: 42, f: 4 },
      { label: "Steamed veg", qty: 200, unit: "g", kcal: 70, p: 3, c: 12, f: 0 },
    ]},
    { name: "Shawarma plate (lean)", items: [
      { label: "Chicken shawarma (grilled)", qty: 180, unit: "g", kcal: 320, p: 45, c: 5, f: 12 },
      { label: "Pita (wholegrain)", qty: 1, unit: "piece", kcal: 170, p: 6, c: 35, f: 1 },
      { label: "Hummus", qty: 60, unit: "g", kcal: 170, p: 5, c: 10, f: 12 },
      { label: "Tabbouleh", qty: 120, unit: "g", kcal: 110, p: 3, c: 16, f: 4 },
    ]},
  ],
  dinner: [
    { name: "Salmon & potato", items: [
      { label: "Salmon (baked)", qty: 180, unit: "g", kcal: 360, p: 38, c: 0, f: 22 },
      { label: "Baby potatoes", qty: 250, unit: "g", kcal: 200, p: 5, c: 46, f: 0 },
      { label: "Green veg", qty: 200, unit: "g", kcal: 60, p: 4, c: 10, f: 0 },
      { label: "Olive oil drizzle", qty: 10, unit: "g", kcal: 90, p: 0, c: 0, f: 10 },
    ]},
    { name: "Grilled chicken wrap", items: [
      { label: "Chicken breast (cooked)", qty: 160, unit: "g", kcal: 264, p: 48, c: 0, f: 6 },
      { label: "Large tortilla (wholegrain)", qty: 1, unit: "wrap", kcal: 220, p: 8, c: 38, f: 5 },
      { label: "Light mayo + veg", qty: 1, unit: "serving", kcal: 120, p: 2, c: 6, f: 9 },
    ]},
    { name: "Stir-fry (high protein)", items: [
      { label: "Turkey mince (cooked)", qty: 200, unit: "g", kcal: 300, p: 50, c: 0, f: 10 },
      { label: "Rice noodles", qty: 120, unit: "g", kcal: 190, p: 4, c: 42, f: 1 },
      { label: "Stir-fry veg + sauce", qty: 250, unit: "g", kcal: 150, p: 4, c: 24, f: 4 },
    ]},
  ],
  snacks: [
    { name: "Protein shake", items: [ { label: "Whey protein", qty: 1, unit: "scoop", kcal: 120, p: 24, c: 3, f: 2 } ] },
    { name: "Nuts mix", items: [ { label: "Almonds & walnuts", qty: 30, unit: "g", kcal: 180, p: 6, c: 6, f: 15 } ] },
    { name: "Fruit", items: [ { label: "Apple or orange", qty: 1, unit: "medium", kcal: 95, p: 1, c: 25, f: 0 } ] },
    { name: "Dark chocolate", items: [ { label: "85% cacao", qty: 20, unit: "g", kcal: 120, p: 2, c: 6, f: 9 } ] },
    { name: "Labneh & cucumbers", items: [ { label: "Labneh (light)", qty: 100, unit: "g", kcal: 120, p: 10, c: 6, f: 6 } ] },
  ]
};

const WORKOUT_SPLIT = [
  { day: "Mon", name: "Lower Body Strength", blocks: ["Back squat 4x6","Romanian deadlift 3x8","Walking lunges 3x12/leg","Leg press 3x12","Core: Planks 3x45s","Optional: 10–15 min incline walk"]},
  { day: "Tue", name: "Upper Body Push", blocks: ["Bench press 4x6","Overhead press 3x8","Incline dumbbell press 3x10","Cable fly 3x12","Push-ups 2xAMRAP","10 min easy bike"]},
  { day: "Wed", name: "Cardio Intervals", blocks: ["Warm-up 8 min","8x(1 min hard + 1 min easy) on rower/bike","Cool-down 8 min","Mobility 10 min"]},
  { day: "Thu", name: "Upper Body Pull", blocks: ["Deadlift 4x5 (moderate)","Pull-ups/lat pulldown 4x8","Seated row 3x10","Face pulls 3x15","Biceps curls 3x12","10 min brisk walk"]},
  { day: "Fri", name: "Conditioning + Core", blocks: ["Bike/Assault 20–30 min Zone 2","Kettlebell swings 4x15","Farmer carries 6x40m","Core circuit x3: dead bug 12, side plank 30s/side, hollow hold 20s"]},
  { day: "Sat", name: "Rugby Skills / Active", blocks: ["Skills: passing & footwork 30 min","Sled pushes 6x20m","Stretch 10–15 min","Optional: friendly game"]},
  { day: "Sun", name: "Rest / Mobility", blocks: ["Walk 30–60 min","Full-body mobility 20 min","Breathing 5 min"]},
];

function dayIndexFromDate(d:string){ return new Date(d).getDay(); }
function todaysWorkout(dateStr:string){ const map=[6,0,1,2,3,4,5]; return WORKOUT_SPLIT[ map[dayIndexFromDate(dateStr)] ]; }

export default function App(){
  const [profile, setProfile] = useState(()=> loadState().profile ?? { weightKg:125, heightCm:178, age:30, sex:"male", activity:"moderate", goalKgPerWeek:0.6 });
  const [dateStr, setDateStr] = useState<string>(dateKey());

  useEffect(()=>{ const s=loadState(); s.profile=profile; saveState(s); },[profile]);

  const bmr = useMemo(()=>calcBMR(profile),[profile]);
  const tdee = useMemo(()=>bmr * activityMultiplier(profile.activity),[bmr, profile.activity]);
  const deficit = useMemo(()=>dailyDeficitFromGoal(profile.goalKgPerWeek),[profile.goalKgPerWeek]);
  const targetKcal = useMemo(()=> clamp(Math.round(tdee - deficit), 1600, 3500), [tdee, deficit]);
  const macros = useMemo(()=>macroSplit({targetKcal, weightKg: profile.weightKg}), [targetKcal, profile.weightKg]);

  const [dayState, setDayState] = useState<any>(()=> loadState().days?.[dateStr] ?? { meals:{}, workoutDone:false, hydrationMl:0, steps:0 });
  useEffect(()=>{ const all=loadState(); if(!all.days) all.days={}; all.days[dateStr]=dayState; saveState(all); },[dayState, dateStr]);
  useEffect(()=>{ const s = loadState().days?.[dateStr] ?? { meals:{}, workoutDone:false, hydrationMl:0, steps:0 }; setDayState(s); },[dateStr]);

  const [mealPickIdx, setMealPickIdx] = useState<any>(()=> loadState().mealPicks?.[dateStr] ?? { breakfast:0, lunch:0, dinner:0, snacks:[0,2] });
  useEffect(()=>{ const all=loadState(); if(!all.mealPicks) all.mealPicks={}; all.mealPicks[dateStr]=mealPickIdx; saveState(all); },[mealPickIdx, dateStr]);

  const breakfast = MEAL_LIBRARY.breakfast[ mealPickIdx.breakfast % MEAL_LIBRARY.breakfast.length ];
  const lunch = MEAL_LIBRARY.lunch[ mealPickIdx.lunch % MEAL_LIBRARY.lunch.length ];
  const dinner = MEAL_LIBRARY.dinner[ mealPickIdx.dinner % MEAL_LIBRARY.dinner.length ];
  const snack1 = MEAL_LIBRARY.snacks[ (mealPickIdx.snacks?.[0] ?? 0) % MEAL_LIBRARY.snacks.length ];
  const snack2 = MEAL_LIBRARY.snacks[ (mealPickIdx.snacks?.[1] ?? 1) % MEAL_LIBRARY.snacks.length ];
  const meals = [breakfast,lunch,dinner,snack1,snack2];

  const mealKcals = (meal:any)=> meal.items.reduce((a:any,x:any)=>({kcal:a.kcal+x.kcal,p:a.p+(x.p||0),c:a.c+(x.c||0),f:a.f+(x.f||0)}),{kcal:0,p:0,c:0,f:0});
  const mealTotals = meals.map((m:any)=>({ ...mealKcals(m), name:m.name }));
  const totals = mealTotals.reduce((a:any,m:any)=>({kcal:a.kcal+m.kcal,p:a.p+m.p,c:a.c+m.c,f:a.f+m.f}),{kcal:0,p:0,c:0,f:0});
  const kcalDelta = targetKcal - totals.kcal;

  const toggleMealItemDone = (mealName:string, itemLabel:string)=> setDayState((prev:any)=>{ const m={...(prev.meals||{})}; const key=`${mealName}::${itemLabel}`; m[key]=!m[key]; return {...prev, meals:m}; });
  const resetDay = ()=> setDayState({ meals:{}, workoutDone:false, hydrationMl:0, steps:0 });
  const completionRate = ()=>{ const totalItems = meals.reduce((a,m)=>a+m.items.length,0)+1; const doneItems = Object.values(dayState.meals||{}).filter(Boolean).length + (dayState.workoutDone?1:0); return Math.round((doneItems/totalItems)*100); };
  const wk = todaysWorkout(dateStr);

  const [streak, setStreak] = useState(0);
  useEffect(()=>{ const all=loadState(); let s=0; for(let i=0;i<365;i++){ const d=new Date(); d.setDate(d.getDate()-i); const k=dateKey(d); const ds=all.days?.[k]; if(!ds) break; const mCount=Object.values(ds.meals||{}).filter(Boolean).length; const totalItems= (Object.keys(ds.meals||{}).length||14)+1; const rate=Math.round(((mCount+(ds.workoutDone?1:0))/(totalItems||1))*100); if(rate>=60) s++; else break; } setStreak(s); },[dateStr, dayState]);

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-white to-slate-100 text-slate-900">
      <div className="mx-auto max-w-5xl px-4 py-6">
        <header className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Weight Loss Planner</h1>
            <p className="text-sm text-slate-600">Daily food + workout plan with check-offs. Offline capable (PWA).</p>
          </div>
          <button className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 text-white" onClick={()=>document.getElementById('settings')?.showModal()}>
            <Settings className="w-4 h-4"/> Settings
          </button>
        </header>

        <section className="mt-6 grid md:grid-cols-3 gap-4">
          <div className="md:col-span-2 p-4 rounded-2xl bg-white shadow">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2"><Calendar className="w-4 h-4"/>
                <input type="date" className="px-2 py-1 rounded-lg bg-slate-100" value={dateStr} onChange={(e)=>setDateStr(e.target.value)} />
              </div>
              <div className="ml-auto flex items-center gap-2 text-sm">
                <Flame className="w-4 h-4"/>
                Target: <b>{targetKcal}</b> kcal · P {macros.proteinG}g • C {macros.carbsG}g • F {macros.fatG}g
              </div>
            </div>

            <div className="mt-4 grid sm:grid-cols-2 gap-4">
              {[{ key:'breakfast', icon:<Sun className="w-4 h-4"/>, data:breakfast },{ key:'lunch', icon:<Salad className="w-4 h-4"/>, data:lunch },{ key:'dinner', icon:<Salad className="w-4 h-4 rotate-180"/>, data:dinner },{ key:'snack1', icon:<Salad className="w-4 h-4"/>, data:snack1 },{ key:'snack2', icon:<Salad className="w-4 h-4"/>, data:snack2 }].map((m:any)=>{
                const totals = mealTotals.find((t:any)=>t.name===m.data.name)!;
                return (
                  <div key={m.key} className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold flex items-center gap-2">{m.icon}{m.data.name}</h3>
                      <button className="text-sm underline" onClick={()=>{
                        if(m.key.startsWith('snack')){
                          const idxSnack = m.key === 'snack1' ? 0 : 1;
                          setMealPickIdx((prev:any)=>({ ...prev, snacks: prev.snacks.map((v:number,i:number)=> i===idxSnack ? v+1 : v)}));
                        } else {
                          setMealPickIdx((prev:any)=>({ ...prev, [m.key]: (prev[m.key]??0)+1 }));
                        }
                      }}>Swap</button>
                    </div>
                    <div className="mt-2 text-xs text-slate-600">~{totals.kcal} kcal • P {totals.p}g • C {totals.c}g • F {totals.f}g</div>
                    <ul className="mt-3 space-y-2">
                      {m.data.items.map((it:any)=>{
                        const key = `${m.data.name}::${it.label}`;
                        const done = !!dayState.meals?.[key];
                        return (
                          <li key={key} className={`flex items-center gap-2 p-2 rounded-xl ${done? 'bg-emerald-50':'bg-transparent'}`}>
                            <button onClick={()=>toggleMealItemDone(m.data.name, it.label)}>{done? <CheckCircle className="w-5 h-5 text-emerald-500"/>: <Circle className="w-5 h-5"/>}</button>
                            <div className="text-sm">
                              <div className="font-medium">{it.label}</div>
                              <div className="text-xs text-slate-500">{it.qty} {it.unit}</div>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold flex items-center gap-2"><Dumbbell className="w-4 h-4"/> Workout – {wk.name}</h3>
                <button className="text-sm underline" onClick={()=>setDayState((p:any)=>({...p, workoutDone: !p.workoutDone}))}>{dayState.workoutDone? 'Undo':'Mark done'}</button>
              </div>
              <ol className="mt-2 grid sm:grid-cols-2 gap-2 list-decimal list-inside text-sm">
                {wk.blocks.map((b:string,i:number)=>(<li key={i} className="p-2 rounded-lg bg-white">{b}</li>))}
              </ol>
            </div>
          </div>

          <aside className="p-4 rounded-2xl bg-white shadow space-y-4">
            <div className="p-3 rounded-xl bg-slate-50 border">
              <div className="flex items-center gap-2 text-sm"><Flame className="w-4 h-4"/> Daily Summary</div>
              <div className="mt-2 text-xs text-slate-600">Planned: <b>{totals.kcal}</b> kcal (P {totals.p} / C {totals.c} / F {totals.f})</div>
              <div className="text-xs text-slate-600">Target: <b>{targetKcal}</b> kcal {kcalDelta>0? `(${kcalDelta} left)` : `(${Math.abs(kcalDelta)} over)`}</div>
              <div className="mt-2 flex items-center gap-2">
                <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden"><div className="h-3 rounded-full bg-emerald-500" style={{width: `${Math.min(100, Math.max(0, completionRate()))}%`}}/></div>
                <span className="text-xs w-10 text-right">{completionRate()}%</span>
              </div>
              <div className="mt-2 text-xs">Streak: <b>{streak}</b> day{streak===1? '':'s'} (≥60%)</div>
              <div className="mt-3 flex items-center gap-2">
                <button className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 text-white" onClick={resetDay}><RefreshCw className="w-4 h-4"/> Reset day</button>
                <button className="inline-flex items-center gap-2 px-3 py-2 rounded-xl border" onClick={()=>window.print()}><Download className="w-4 h-4"/> Print</button>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border space-y-2">
              <div className="text-sm font-medium">Hydration & Steps</div>
              <div className="text-xs text-slate-500">Aim ~35–45 ml/kg/day. For {profile.weightKg} kg: {round(profile.weightKg*40)} ml ≈ {round(profile.weightKg*0.04,1)} L</div>
              <div className="flex items-center gap-2">
                <input type="number" className="px-2 py-1 rounded-lg bg-slate-100 w-28" value={dayState.hydrationMl} onChange={e=>setDayState((p:any)=>({...p, hydrationMl: clamp(parseInt(e.target.value||'0'), 0, 10000)}))} />
                <span className="text-sm">ml today</span>
              </div>
              <div className="flex items-center gap-2">
                <input type="number" className="px-2 py-1 rounded-lg bg-slate-100 w-28" value={dayState.steps} onChange={e=>setDayState((p:any)=>({...p, steps: clamp(parseInt(e.target.value||'0'), 0, 100000)}))} />
                <span className="text-sm">steps</span>
              </div>
            </div>
          </aside>
        </section>
      </div>

      <dialog id='settings' className='backdrop:bg-black/50 rounded-2xl w-[680px] max-w-[94vw]'>
        <form method='dialog' className='p-5 bg-white rounded-2xl shadow-xl'>
          <div className='flex items-center justify-between'>
            <h2 className='text-lg font-semibold'>Your Profile & Goal</h2>
            <button className='px-3 py-1 rounded-lg border'>Close</button>
          </div>
          <div className='grid grid-cols-2 gap-3 mt-4'>
            <label className='text-sm'>Weight (kg)
              <input type='number' className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.weightKg} onChange={e=>setProfile((p:any)=>({...p, weightKg: clamp(parseFloat(e.target.value||'0'), 40, 250)}))}/>
            </label>
            <label className='text-sm'>Height (cm)
              <input type='number' className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.heightCm} onChange={e=>setProfile((p:any)=>({...p, heightCm: clamp(parseFloat(e.target.value||'0'), 140, 220)}))}/>
            </label>
            <label className='text-sm'>Age
              <input type='number' className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.age} onChange={e=>setProfile((p:any)=>({...p, age: clamp(parseInt(e.target.value||'0'), 14, 80)}))}/>
            </label>
            <label className='text-sm'>Sex
              <select className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.sex} onChange={e=>setProfile((p:any)=>({...p, sex: e.target.value}))}>
                <option value='male'>Male</option>
                <option value='female'>Female</option>
              </select>
            </label>
            <label className='text-sm'>Activity level
              <select className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.activity} onChange={e=>setProfile((p:any)=>({...p, activity: e.target.value}))}>
                <option value='sedentary'>Sedentary</option>
                <option value='light'>Light (1–3x/wk)</option>
                <option value='moderate'>Moderate (3–4x/wk)</option>
                <option value='active'>Active (5–6x/wk)</option>
                <option value='athlete'>Athlete (2x/day)</option>
              </select>
            </label>
            <label className='text-sm'>Goal pace
              <select className='mt-1 w-full px-2 py-1 rounded-lg bg-slate-100' value={profile.goalKgPerWeek} onChange={e=>setProfile((p:any)=>({...p, goalKgPerWeek: parseFloat(e.target.value)}))}>
                <option value={0.5}>0.5 kg/week (gentle)</option>
                <option value={0.6}>0.6 kg/week</option>
                <option value={0.75}>0.75 kg/week</option>
                <option value={1.0}>1.0 kg/week (aggressive)</option>
              </select>
            </label>
          </div>
          <div className='mt-2 text-xs text-slate-500'>Estimates only; adjust if you feel overly hungry or fatigued. Check with a clinician if you have medical conditions.</div>
        </form>
      </dialog>
    </div>
  );
}
