export type Profile = { sex: "male" | "female"; weightKg: number; heightCm: number; age: number; };
export const clamp = (n:number, min:number, max:number)=> Math.max(min, Math.min(max, n));
export const round = (n:number, dp=0)=> { const p = Math.pow(10, dp); return Math.round(n*p)/p; };
export const calcBMR = ({sex, weightKg, heightCm, age}:Profile) => (10*weightKg + 6.25*heightCm - 5*age + (sex === "female" ? -161 : 5));
export const activityMultiplier = (level:string)=> ({sedentary:1.2, light:1.375, moderate:1.55, active:1.725, athlete:1.9}[level as any] || 1.55);
export const dailyDeficitFromGoal = (goalKgPerWeek:number)=> clamp(goalKgPerWeek * 7700 / 7, 200, 1200);
export const macroSplit = ({targetKcal, weightKg}:{targetKcal:number, weightKg:number})=>{
  const proteinG = 1.8 * weightKg; // 1.8 g/kg
  const fatG = 0.8 * weightKg;     // 0.8 g/kg
  const kcalAfterPF = proteinG*4 + fatG*9;
  const carbsG = Math.max(0, (targetKcal - kcalAfterPF) / 4);
  return { proteinG: round(proteinG), carbsG: round(carbsG), fatG: round(fatG) };
};
