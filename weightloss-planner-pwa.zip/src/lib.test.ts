import { describe, it, expect } from "vitest";
import { calcBMR, activityMultiplier, dailyDeficitFromGoal, macroSplit } from "./lib";
describe("calculations", () => {
  it("calculates BMR (Mifflin-St Jeor)", () => {
    const bmr = calcBMR({ sex: "male", weightKg: 125, heightCm: 178, age: 30 });
    expect(Math.round(bmr)).toBe(2218);
  });
  it("applies activity multiplier", () => {
    expect(activityMultiplier("moderate")).toBeCloseTo(1.55, 2);
  });
  it("computes daily deficit from weekly goal", () => {
    expect(Math.round(dailyDeficitFromGoal(0.6))).toBe(660);
    expect(Math.round(dailyDeficitFromGoal(1.0))).toBe(1100);
  });
  it("macro split ~ target kcal", () => {
    const targetKcal = 2777;
    const out = macroSplit({ targetKcal, weightKg: 125 });
    const kcal = out.proteinG*4 + out.carbsG*4 + out.fatG*9;
    expect(Math.abs(kcal - targetKcal)).toBeLessThanOrEqual(100);
  });
});
