# Weight Loss Planner (PWA)

1) `npm i`
2) `npm run build`
3) Deploy to Vercel (set Output Directory = dist)

Open on iPhone Safari → Share → Add to Home Screen.
